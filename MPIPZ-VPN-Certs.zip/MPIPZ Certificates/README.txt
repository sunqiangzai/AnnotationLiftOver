##############################################
##                                          ##
##               MPIPZ  -  VPN              ##
##                                          ##
##############################################

Install the certificates by double-clicking on the files in the following order:

1. intermediatecacert.crt
2. cacert.crt
3. VPN-USER-2015-1.p12

Loading the last file will prompt for a password. If you haven't received this
password yet, please email us (it@mpipz.mpg.de).
